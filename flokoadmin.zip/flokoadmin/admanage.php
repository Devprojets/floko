<?php
@include('php/connection.php');
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Floko Admin</title>
    <link rel="stylesheet" href="css/app.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  </head>
  <body>
    <div class="container-fluid">
        <div class="row">
         <div class="col-sm-2 sidebar text-center">
         <?php @require('modules/sidebar.php'); ?>
         </div>
         <div class="col-sm-10 content">
          <div class="row pt-3">
            <div class="col-sm-12 text-center">
                <h3 class="page_head">Ad Management</h3>
            </div>
          </div>
          <div class="row">
            <div class="col-sm-12 text-end">
            <button type="button" class="btn btn-pink" data-bs-toggle="modal" data-bs-target="#addnewad">
  Add New
</button>

<!-- Modal -->
<div class="modal fade" id="addnewad" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add New Ad</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="row">
          <div class="col-sm-12">
            <form action="php/admin.php" method="POST" enctype="multipart/form-data">
              <input type="text" class="form-control" placeholder="Title" name="title">  <br>
              <textarea name="description" id="" cols="30" rows="5" class="form-control" placeholder="Description"></textarea> <br>
              <input type="text" name="niche" placeholder="Niche" id="" class="form-control"> <br>
              <input type="file" name="pic" placeholder="Picture" class="form-control" id="">
              <br>
              <input type="submit" value="Save" class="btn btn-pink" name="save_add">
            </form>
          </div>
        </div>
      </div>
      <div class="modal-footer">
       
      </div>
    </div>
  </div>
</div>
            </div>
          </div>
          <br><br>
          <div class="row">
            <div class="col-sm-12">
                <table class="table">
                    <thead id="thead">
                   
                      <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Image</th>
                        <th scope="col">Title</th>
                        <th scope="col">Category</th>
                        <th scope="col">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php
                      $sql = "select * from ads_db";
                      $result = mysqli_query($con,$sql);
                      while($row = mysqli_fetch_array($result))
                      {
                      ?>
                      <tr class="align-middle">
                        <td scope="row"><?php echo $row['id']; ?></td>
                        <td><img src="images/adsphoto/<?php echo $row['photo']; ?>" width="100" class="img-fluid " alt=""></td>
                        
                        <td><?php echo $row['title']; ?></td> 
                        <td><?php echo $row['niche']; ?></td>
                        <td>
                                       <!-- modal here -->
<!-- Button trigger modal -->
<button type="button" class="btn btn-pink" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo $row['id']; ?>">
  Manage
</button>

<!-- Modal -->
<div class="modal fade" id="exampleModal<?php echo $row['id']; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Ad Manage</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="row">
          <div class="col-sm-12">
          <form action="php/admin.php" method="post">
          <input type="hidden" name="id" value="<?php echo $row['id']; ?>" id="">
          <input type="submit" value="Delete" name="delad" class="btn btn-danger">
        </form>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        
      </div>
    </div>
  </div>
</div>

<!-- modal end -->
                        </td>
                      </tr>
                    <?php
                      }
                    ?>
                    </tbody>
                  </table>
            </div>
          </div>
         </div>
        </div>
      </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
  </body>
</html>