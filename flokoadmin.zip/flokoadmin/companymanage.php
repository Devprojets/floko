<?php
@include('php/connection.php');

?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Floko Admin</title>
    <link rel="stylesheet" href="css/app.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  </head>
  <body>
    <div class="container-fluid">
        <div class="row">
         <div class="col-sm-2 sidebar text-center">
         <?php @include('modules/sidebar.php'); ?>
         </div>
         <div class="col-sm-10 content">
          <div class="row pt-3">
            <div class="col-sm-12 text-center">
                <h3 class="page_head">Company Management</h3>
            </div>
          </div>
          <br><br>
          <div class="row">
            <div class="col-sm-12">
                <table class="table">
                    <thead id="thead">
                      <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Doamin</th>
                        <th scope="col">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      $sql = "select * from comp_db";
                      $result = mysqli_query($con,$sql);
                      while($row = mysqli_fetch_array($result))
                      {
                      ?>
                      <tr class="align-middle">
                        <th scope="row"><?php echo $row['id']; ?></th>
                        <td><?php echo $row['name']; ?></td>
                        <td><?php echo $row['email']; ?></td>
                        <td><?php echo $row['domain']; ?></td>
                        <td>
                                       <!-- modal here -->
<!-- Button trigger modal -->
<button type="button" class="btn btn-pink" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo $row['id']; ?>">
  Manage
</button>

<!-- Modal -->
<div class="modal fade" id="exampleModal<?php echo $row['id']; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Company Manage</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <h3>Update Password</h3>
       <form action="php/admin.php" method="post">
       <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
        <input type="password" placeholder="Enter New Password" name="pass" class="form-control">
        <br>
        <input type="submit" value="Update" name="update_comp" class="btn btn-pink">
        <br><br>
        <input type="submit" value="Delete User" name="delete_comp" class="btn btn-danger">
       </form>
      </div>
      <div class="modal-footer">
      
      </div>
    </div>
  </div>
</div>

<!-- modal end -->
                        </td>
                      </tr>
                      <?php
                      }
                      ?>
                    
                    </tbody>
                  </table>
            </div>
          </div>
         </div>
        </div>
      </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
  </body>
</html>