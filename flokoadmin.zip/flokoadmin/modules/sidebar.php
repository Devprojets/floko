<?php
$date = date("d-m-Y");
$day = date('l' , strtotime($date));
$time = date("h:i a");
?>
<h2 class="text-white">Welcome Admin</h2>
<br>
<div class="row">
    <div class="col-sm-6">
        <h4 class="text-white"><?php echo $day; ?></h4>
    </div>
    <div class="col-sm-6">
        <h4 class="text-white"><?php echo $time; ?></h4>
    </div>
</div>
          <br><br>
          <a href="dashboard.php" class="btn btn-side form-control">Dashboard</a> 
          <a href="employeemanage.php" class="btn btn-side form-control">Employee Management</a> 
          <a href="companymanage.php" class="btn btn-side form-control">Company Management</a> 
          <a href="admanage.php" class="btn btn-side form-control">Ads Management</a> 
          <a href="usermanage.php" class="btn btn-side form-control">User Management</a> 
          <a href="index.php" class="btn btn-side form-control">Logout</a> 