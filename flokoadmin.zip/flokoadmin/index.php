<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Floko Admin</title>
    <link rel="stylesheet" href="css/app.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  </head>
  <body>
    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-6 lside">
        <div class="row">
          <div class="offset-sm-3 col-sm-6 offset-sm-3">
            <h3 class="text-white">Welcome Admin</h3>
           <form action="php/login.php" method="post">
            <input type="text" name="id" placeholder="Admin ID" id="" class="form-control">
            <br>
            <input type="password" name="pass" placeholder="Password" id="" class="form-control">
            <br>
            <input type="submit" value="Login"  class="btn btn-white">
           </form>
          </div>
        </div>
        </div>
        <div class="col-sm-6 rside text-center">
         <center>
          <h1 class="fp">Floko</h1>
          <br>
          <img src="images/logo 1.png" class="img-fluid" width="400" alt="">
         </center>
        </div>
      </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
  </body>
</html>