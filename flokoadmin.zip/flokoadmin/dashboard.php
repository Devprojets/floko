<?php
@include('php/connection.php');

$getemp = "select count(id) as empcount from user_db";
$reemp = mysqli_query($con,$getemp);
$rowemp = mysqli_fetch_array($reemp);

// getcomp

$getcom = "select count(id) as comcount from comp_db";
$recom = mysqli_query($con,$getcom);
$rowcom = mysqli_fetch_array($recom);
// getcomp

$getad = "select count(id) as adcount from ads_db";
$read = mysqli_query($con,$getad);
$rowad = mysqli_fetch_array($read);
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Floko Admin</title>
    <link rel="stylesheet" href="css/app.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  </head>
  <body>
    <div class="container-fluid">
      <div class="row">
       <div class="col-sm-2 sidebar text-center">
       <?php @require('modules/sidebar.php'); ?>
       </div>
       <div class="col-sm-10 content">
        <div class="row call_box">
          <div class="box">
            <h1>Total Employees</h1>
            <h5><?php echo $rowemp['empcount']; ?></h5>
            <a href="" class="btn btn-white">Manage</a>
          </div>
          <div class="box">
            <h1>Total Companies</h1>
            <h5><?php echo $rowcom['comcount']; ?></h5>
            <a href="" class="btn btn-white">Manage</a>
          </div>
          <div class="box">
            <h1><?php echo $rowad['adcount']; ?></h1>
            <h5>99</h5>
            <a href="" class="btn btn-white">Manage</a>
          </div>
        </div>
        <br><br><br>
        <div class="row ">
          <div class="col-sm-6 pl">
            <h2>Your Current Packages</h2>
            <ul>
              <li>Silver</li>
              <li>Gold</li>
              <li>Diamond</li>
              <li>Plantanium</li>
            </ul>
            <a href="packagemanage.php" class="btn btn-pink">Offer More</a>
          </div>
<div class="col-sm-6 pr">
<h1>Manage Your Current Packages</h1>
<a href="packagemanage.php" class="btn btn-white">Manage</a>
</div>
        </div>
       </div>
      </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
  </body>
</html>