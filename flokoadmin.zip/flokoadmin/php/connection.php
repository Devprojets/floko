<?php
$username= "root";
$server = "localhost";
$dbname = "floko";
$pass = "";

$con =  mysqli_connect($server,$username,$pass,$dbname);

if($con){
    // echo "Connected";
}
else{
    echo "DB Error";
}
?>
