<?php
@include('connection.php');

if(isset($_POST['saveadmin'])){
    $id = "Admin" . rand(10,1000);
    $name = $_POST['name'];
    $email = $_POST['email'];
    $pass = $_POST['pass'];
    $check = "select * from admins_db where email = '$email'";
    $result = mysqli_query($con,$check);
    $row= mysqli_num_rows($result);
    $sql = "insert into admins_db Values('$id','$name','$email','$pass')";
    if($row == 0){
        mysqli_query($con,$sql);
        echo '<script>alert("Admin Registered Succesfully");</script>';
        header("refresh:0.1 url=../usermanage.php");
    }
    else{
        echo '<script>alert("Email Already Exists");</script>';
        header("refresh:0.1 url=../usermanage.php");
    }
  
}

?>