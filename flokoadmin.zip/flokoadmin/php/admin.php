<?php
@include('connection.php');

if(isset($_POST['savepack'])){
  

 $id = rand(10,1000);
  
    $title = $_POST['title'];

    if(empty($_POST['swipe'])){
        $swipe = "Null";
    }
    else{
        $swipe = $_POST['swipe'];
    }
    if(empty($_POST['redo'])){
        $redo = "Null";
    }
    else{
        $redo = $_POST['redo'];
    }
    if(empty($_POST['ciar'])){
        $ciar = "Null";
    }
    else{
        $ciar = $_POST['ciar'];
    }
    if(empty($_POST['cam'])){
        $cam = "Null";
    }
    else{
        $cam = $_POST['cam'];
    }
    if(empty($_POST['ss'])){
        $ss = "Null";
    }
    else{
        $ss = $_POST['ss'];
    }
    if(empty($_POST['boost'])){
        $boost = "Null";
    }
    else{
        $boost = $_POST['boost'];
    }
    if(empty($_POST['sm'])){
        $sm = "Null";
    }
    else{
        $sm = $_POST['sm'];
    }
    

    $sql = "insert into packages_db values('$id','$title','$swipe','$redo','$ciar','$cam','$ss','$boost','$ss')";
    if(mysqli_query($con,$sql)){
        echo '<script>alert("Package Added Succesfully");</script>';
        header("refresh:0.1 url=../packagemanage.php");
    }
   
}
if(isset($_POST['delpack'])){
    $id = $_POST['id'];
    $sql = "DELETE FROM packages_db where id = '$id'";
    if(mysqli_query($con,$sql)){
        echo '<script>alert("Package Deleted Succesfully");</script>';
        header("refresh:0.1 url=../packagemanage.php");
    }
}
if(isset($_POST['delad'])){
    $id = $_POST['id'];
    $sql = "DELETE FROM ads_db where id = '$id'";
    if(mysqli_query($con,$sql)){
        echo '<script>alert("Ad Deleted Succesfully");</script>';
        header("refresh:0.1 url=../admanage.php");
    }
}
if(isset($_POST['delete_user'])){
    $id = $_POST['id'];
    $sql = "DELETE FROM user_db where id = '$id'";
    if(mysqli_query($con,$sql)){
        echo '<script>alert("Employee Deleted Succesfully");</script>';
        header("refresh:0.1 url=../employeemanage.php");
    }
}
if(isset($_POST['update_user'])){
    $id = $_POST['id'];
    $pass = $_POST['pass'];
    $sql = "Update user_db SET pass = '$pass' where id = '$id'";
    if(mysqli_query($con,$sql)){
        echo '<script>alert("Employee Record Updated Succesfully");</script>';
        header("refresh:0.1 url=../employeemanage.php");
    }
}
if(isset($_POST['delete_comp'])){
    $id = $_POST['id'];
    $sql = "DELETE FROM comp_db where id = '$id'";
    if(mysqli_query($con,$sql)){
        echo '<script>alert("Company Deleted Succesfully");</script>';
        header("refresh:0.1 url=../companymanage.php");
    }
}
if(isset($_POST['update_comp'])){
    $id = $_POST['id'];
    $pass = $_POST['pass'];
    $sql = "Update comp_db SET pass = '$pass' where id = '$id'";
    if(mysqli_query($con,$sql)){
        echo '<script>alert("Company Record Updated Succesfully");</script>';
        header("refresh:0.1 url=../companymanage.php");
    }
}
if(isset($_POST['save_add'])){
    $id = rand(10,30000);
    $title = $_POST['title'];
    $description = $_POST['description'];
    $niche = $_POST['niche'];
    $pic= $_FILES['pic']['name'];
    $target = "../images/adsphoto/".basename($pic); 

    $sql = "insert into ads_db Values('$id','$title','$description','$pic','$niche')";

    if(mysqli_query($con,$sql) && move_uploaded_file($_FILES['pic']['tmp_name'], $target)){
        echo '<script>alert("Ad Saved Succesfully");</script>';
        header("refresh:0.1 url=../admanage.php");
    }
}

?>