<?php
@include('connection.php');

$adminid = $_POST['id'];
$pass = $_POST['pass'];

$sql = "select * from admins_db where id = '$adminid'";
$result = mysqli_query($con,$sql);
$row = mysqli_fetch_array($result);

if($row['id'] == $adminid && $row['pass'] == $pass){
    echo '<script>alert("Logged In Succesfully");</script>';
    header("refresh:0.1 url=../dashboard.php");
}
else{
    echo '<script>alert("Logged In Failed Please Check Credentials");</script>';
    header("refresh:0.1 url=../dashboard.php");
}

?>